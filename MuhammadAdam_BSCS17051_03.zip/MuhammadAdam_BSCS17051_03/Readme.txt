At the top of the code there is a variable called img, where you can input the image to be used.

At the very bottom are all the images that are being outputted.

Through comment headings, sections of the code is seperated.